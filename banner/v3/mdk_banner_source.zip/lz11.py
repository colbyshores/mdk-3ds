# LZ11 (Nintendo) compressor/decompressor.
def decompress(src):
    assert src[0] == 0x11
    size = src[1] | src[2] << 8 | src[3] << 16; p = 4
    if size == 0: size = int.from_bytes(src[4:8], 'little'); p = 8
    out = bytearray()
    while len(out) < size:
        flags = src[p]; p += 1
        for bit in range(8):
            if len(out) >= size: break
            if not flags & (0x80 >> bit):
                out.append(src[p]); p += 1; continue
            b0 = src[p]; ind = b0 >> 4
            if ind == 0:
                ln = (((b0 & 0xF) << 4) | (src[p+1] >> 4)) + 0x11
                disp = (((src[p+1] & 0xF) << 8) | src[p+2]) + 1; p += 3
            elif ind == 1:
                ln = (((b0 & 0xF) << 12) | (src[p+1] << 4) | (src[p+2] >> 4)) + 0x111
                disp = (((src[p+2] & 0xF) << 8) | src[p+3]) + 1; p += 4
            else:
                ln = ind + 1; disp = (((b0 & 0xF) << 8) | src[p+1]) + 1; p += 2
            for _ in range(ln): out.append(out[-disp])
    return bytes(out), p

def compress(data):
    n = len(data); out = bytearray([0x11, n & 0xFF, (n >> 8) & 0xFF, (n >> 16) & 0xFF])
    assert n < 1 << 24
    # hash chains over 3-byte prefixes, window 4096
    head = {}; prev = [-1] * n
    def match(i):
        best_len, best_disp = 0, 0
        if i + 3 > n: return 0, 0
        j = head.get(data[i:i+3], -1); tries = 0
        maxlen = min(0x10110, n - i)
        while j >= 0 and i - j <= 0x1000 and tries < 256:
            l = 3
            while l < maxlen and data[j + l] == data[i + l]: l += 1
            if l > best_len:
                best_len, best_disp = l, i - j
                if l == maxlen: break
            j = prev[j]; tries += 1
        return best_len, best_disp
    def insert(i):
        if i + 3 <= n:
            k = data[i:i+3]; prev[i] = head.get(k, -1); head[k] = i
    i = 0
    while i < n:
        flag_pos = len(out); out.append(0); flags = 0
        for bit in range(8):
            if i >= n: break
            l, d = match(i)
            if l >= 3:
                flags |= 0x80 >> bit; d -= 1
                if l <= 0x10:
                    out += bytes([((l - 1) << 4) | (d >> 8), d & 0xFF])
                elif l <= 0x110:
                    l2 = l - 0x11
                    out += bytes([l2 >> 4, ((l2 & 0xF) << 4) | (d >> 8), d & 0xFF])
                else:
                    l2 = l - 0x111
                    out += bytes([0x10 | (l2 >> 12), (l2 >> 4) & 0xFF, ((l2 & 0xF) << 4) | (d >> 8), d & 0xFF])
                for k in range(l): insert(i + k)
                i += l
            else:
                out.append(data[i]); insert(i); i += 1
        out[flag_pos] = flags
    return bytes(out)
