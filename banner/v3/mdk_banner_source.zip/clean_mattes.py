# Rebuilds flc/kurt_clean/ from the raw difference mattes in flc/kurt/.
# 1) drop warm (orange/red) plate leaks, tiny islands and bright 1-px slivers
# 2) for frames on the letters, drop letter-coloured leaks along/below the letters' top edge
# 3) grow the matte a few px into faint dark edges (dark helmet over the near-black sky) that the
#    original threshold missed, staying above the letters and avoiding warm pixels
import json, os
import numpy as np
from PIL import Image
from scipy import ndimage

FLC = "/home/claude/flc"
os.makedirs(f"{FLC}/kurt_clean", exist_ok=True)
offs = {int(k): v for k, v in json.load(open(f"{FLC}/kurt/offsets.json")).items()}
plate = np.asarray(Image.open(f"{FLC}/frames/f001.png").convert("RGB")).astype(int)
EDGE, PAD = 125, 6
# letter pixels of the logo in the clean plate: below the letters' top edge and not the red/orange glow
_pr, _pg = plate[..., 0], plate[..., 1]
LETTERS = np.zeros(plate.shape[:2], bool)
LX0, LX1 = 198, 412                      # horizontal extent of the MDK letters in the plate
LETTERS[EDGE - 4:300, LX0:LX1] = ((_pr - _pg) < 70)[EDGE - 4:300, LX0:LX1]
out_offs = {}

def keep_big(a, frac=0.04, minpx=25):
    lab, n = ndimage.label(a)
    if not n: return a
    sizes = ndimage.sum(a, lab, range(1, n + 1))
    return np.isin(lab, 1 + np.nonzero(sizes >= max(minpx, frac * sizes.max()))[0])

for i, (x0, y0, x1, y1) in sorted(offs.items()):
    X0, Y0, X1, Y1 = max(0, x0 - PAD), max(0, y0 - PAD), min(600, x1 + PAD), min(360, y1 + PAD)
    fr = np.asarray(Image.open(f"{FLC}/frames/f{i:03d}.png").convert("RGB")).astype(int)[Y0:Y1, X0:X1]
    pl = plate[Y0:Y1, X0:X1]
    d = np.abs(fr - pl).sum(2)
    yy = np.arange(Y0, Y1)[:, None] + np.zeros((1, X1 - X0), int)
    a = np.zeros(fr.shape[:2], bool)
    a[y0 - Y0:y1 - Y0, x0 - X0:x1 - X0] = np.asarray(Image.open(f"{FLC}/kurt/k{i:03d}.png"))[..., 3] > 0
    warm = (fr[..., 0] - np.maximum(fr[..., 1], fr[..., 2])) > 35
    sat = fr.max(2) - fr.min(2)
    # warm pixels are only background leaks if they also match the plate (keeps Kurt's rust-coloured helmet detail)
    warm = warm & (d < 80)

    # pass 1
    a &= ~warm
    a = keep_big(a)
    vert = np.ones((3, 1))
    thin = a & ~ndimage.binary_dilation(ndimage.binary_erosion(a, structure=vert), structure=vert)
    a &= ~(thin & (fr.sum(2) > 200))
    # pass 2: logo leaks only where the plate is a letter pixel and the colour looks like the letters
    #         (green/tan: blue channel lowest) or matches the plate; Kurt's suit is blue-black/chrome
    letters = LETTERS[Y0:Y1, X0:X1]
    lettery = ((sat > 28) & (fr[..., 2] < np.minimum(fr[..., 0], fr[..., 1]) - 6)) | ((d < 40) & (fr.mean(2) > 60))
    a &= ~(letters & lettery)
    # letter-bevel strips peeking out under his legs: light pixels on the bottom edge of the outline
    lum = fr.mean(2)
    for _ in range(2):
        below = np.zeros_like(a); below[:-1] = a[1:]
        below2 = np.zeros_like(a); below2[:-2] = a[2:]
        bottom_edge = a & ~(below & below2)
        a &= ~(bottom_edge & letters & ((lum > 60) | (fr[..., 1] > fr[..., 2] + 8)))
    a = keep_big(a)
    # pass 3
    # pass 3: grow into faint edges (dark helmet over the dark sky), then trim 1-px spikes from the grown part
    base = a.copy()
    ok = (d > 8) & ~warm & ~letters
    for _ in range(4):
        a |= ndimage.binary_dilation(a) & ok
    grown = a & ~base
    a = base | (grown & ndimage.binary_opening(a, structure=np.ones((2, 2))))
    filled = ndimage.binary_fill_holes(a) & ~warm & ~letters   # never fill background-coloured gaps
    a = a | filled
    a = keep_big(a)

    if not a.any():
        continue
    ys, xs = np.nonzero(a)
    bx0, by0, bx1, by1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    rgba = np.dstack([fr, a * 255]).astype(np.uint8)[by0:by1, bx0:bx1]
    Image.fromarray(rgba).save(f"{FLC}/kurt_clean/k{i:03d}.png")
    out_offs[i] = [int(X0 + bx0), int(Y0 + by0), int(X0 + bx1), int(Y0 + by1)]

json.dump(out_offs, open(f"{FLC}/kurt_clean/offsets.json", "w"))
print("frames:", len(out_offs), "dropped (empty):", sorted(set(offs) - set(out_offs)))
