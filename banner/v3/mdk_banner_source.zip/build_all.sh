#!/usr/bin/env bash
# Builds the v3 fix and the round-2 bisect variants:  PY=<venv python> PYCGFX=<pycgfx checkout> ./build_all.sh <out dir> <cwav>
#   (optional) V2_BNR=<v2 .bnr> also builds bisect variant E
#   venv: gltflib==1.0.13 pillow numpy scipy rectpack;  pycgfx: skyfloogle/pycgfx 1f78850 (or 6c2e0cd) + pycgfx_patch.diff
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="${1:?out dir}"; CWAV="${2:?cwav}"; PY="${PY:-python3}"
build() {   # name, env...
    local name="$1"; shift
    echo "== $name: $*"
    env "$@" "$PY" -I "$HERE/build_scene.py" "$OUT/$name" | tail -1
    env "$@" "$PY" -I "$HERE/make_cgfx.py" "$OUT/$name"
    "$PY" -I "$HERE/make_bnr.py" "$OUT/$name/COMMON.cgfx" "$CWAV" "$OUT/$name/$name.bnr"
}
# ---- round 3: the shipping candidate and its controls (v2's art at full 0.5 scale, 3 sheets) ----------------
# ship: Forsaken's diorama rig (bg and kurt each a root-level billboard-5 bone at the origin) + play once and
#       hold (CANM frame size 36057, Forsaken's hardware-proven value)
build ship          MODE=strip TEX_SCALE=0.5 MAX_SHEETS=3 HOLD_FRAMES=36057
# diorama: the same with v2's 6 s loop, so the rig and the hold can be judged separately
build diorama_loop6 MODE=strip TEX_SCALE=0.5 MAX_SHEETS=3
# onetime: experiment -- CANM loop mode 0 (one-time) instead of a long loop; untested on hardware
build onetime       MODE=strip TEX_SCALE=0.5 MAX_SHEETS=3 LOOP_ONCE=1
# ---- round 2 (bisect) ---------------------------------------------------------------------------------------
# the fix: v2's 29 frames on one billboard bone (vertical film strip), 2 RGBA4 sheets at TEX_SCALE 0.42
build fix    MODE=strip TEX_SCALE=0.42 MAX_SHEETS=2 STEP_EPS=0.001
# C: the fix's structure carrying v2's memory load (3 sheets at 0.5 = v2's 448 KiB, file padded to v2's size)
build C_load MODE=strip TEX_SCALE=0.5 MAX_SHEETS=3 BG_GRID=26 NO_BUDGET=1 STEP_EPS=0.001
# D/B/A: v2's structure (30 meshes, 31 bones) with all frames in ONE small sheet
build D_nodes_noanim  MODE=nodes ANIM=0 TEX_SCALE=0.29 MAX_SHEETS=1
build B_nodes_linear  MODE=nodes ANIM=1 INTERP=LINEAR STEP_EPS=0.001 TEX_SCALE=0.29 MAX_SHEETS=1
build A_nodes_step    MODE=nodes ANIM=1 INTERP=STEP TEX_SCALE=0.29 MAX_SHEETS=1
# E (optional, V2_BNR=<v2's tested mdk_banner_stage1.bnr>): v2's tested banner byte-for-byte, except that
# the rotation-W slot of each of its 29 Transform members is flagged absent (patch_rotw.py). Same CWAV.
if [ -n "${V2_BNR:-}" ]; then
    echo "== E_v2_rotw: $V2_BNR"
    mkdir -p "$OUT/E_v2_rotw"
    "$PY" -I -c "
import struct, sys; sys.path.insert(0, '$HERE'); import lz11
b = open('$V2_BNR', 'rb').read(); c, w = struct.unpack_from('<I', b, 8)[0], struct.unpack_from('<I', b, 0x84)[0]
open('$OUT/E_v2_rotw/v2.cgfx', 'wb').write(lz11.decompress(b[c:])[0]); open('$OUT/E_v2_rotw/v2.bcwav', 'wb').write(b[w:])"
    "$PY" -I "$HERE/patch_rotw.py" "$OUT/E_v2_rotw/v2.cgfx" "$OUT/E_v2_rotw/COMMON.cgfx"
    "$PY" -I "$HERE/make_bnr.py" "$OUT/E_v2_rotw/COMMON.cgfx" "$OUT/E_v2_rotw/v2.bcwav" "$OUT/E_v2_rotw/E_v2_rotw.bnr"
fi
