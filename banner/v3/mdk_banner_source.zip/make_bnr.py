# Packs a CBMD/BNR banner: header (0x88), LZ11 CGFX at 0x88, zero pad to 0x10, CWAV; CWAV offset at 0x84.
import sys, struct
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lz11
cgfx = open(sys.argv[1], 'rb').read(); cwav = open(sys.argv[2], 'rb').read(); out = sys.argv[3]
assert cgfx[:4] == b'CGFX' and cwav[:4] == b'CWAV'
assert len(cgfx) <= 0x80000, f'CGFX too big: {len(cgfx)}'
comp = lz11.compress(cgfx)
assert lz11.decompress(comp)[0] == cgfx, 'LZ11 round trip failed'
hdr = bytearray(0x88); hdr[0:4] = b'CBMD'; struct.pack_into('<I', hdr, 0x08, 0x88)
body = bytes(hdr) + comp
body += b'\0' * ((-len(body)) % 0x10)
struct.pack_into('<I', hdr, 0x84, len(body))
data = bytes(hdr) + body[0x88:] + cwav
open(out, 'wb').write(data)
print('cgfx', len(cgfx), 'lz11', len(comp), 'cwav @', hex(len(body)), 'bnr', len(data))
