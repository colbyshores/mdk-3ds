# glTF -> COMMON.cgfx with pycgfx (pinned 1f78850/6c2e0cd + pycgfx_patch.diff), run in-process so the
# hardware rules can be applied and CHECKED on the object graph before it is written.
#
#   PYCGFX=<pycgfx checkout> python make_cgfx.py <scene dir>      -> <scene dir>/COMMON.cgfx
#
# For MODE=strip scenes (the fix) it applies the rules Forsaken's banner proved on a New 3DS XL
# (../forsaken/banner/SPEC.md section 2 and 9a) and fails the build if any is broken:
#   - one model and one skeletal animation, both named COMMON; no material animation;
#   - rigid node TRS only: skinning mode 0, no bone index/weight streams, every member Transform (5);
#   - flat layers on their own root-level bone AT THE ORIGIN with YAxial billboard (5);
#   - unlit textured materials: TEV stage 0 = texture 0 (rgb and alpha), stages 1-5 pass through,
#     fragment lighting off (pycgfx's PBR specular washes things out under the HOME light);
#   - draw order by render layer (transluscency_kind): bg 0 (depth test + write), Kurt 1 (blended, test only);
#   - RGB565 / RGBA4 textures only, power-of-two, <= 256; Floyd-Steinberg dithered to the stored bits;
#   - and the budget this banner's freeze taught (README.md): <= 8 meshes, <= 8 bones, <= 4 animated
#     members, <= 352 KiB of texture (Forsaken's 360,448 bytes is the largest known to work), CGFX < 512 KiB.
# MODE=nodes scenes (v2's structure, the bisect variants) are converted exactly as v2 was: no post-patch.
import json, os, sys
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.environ.get("PYCGFX", os.path.join(HERE, ".tools", "pycgfx")))
import gltflib                                    # noqa: E402
import main as pycgfx                             # noqa: E402  (pycgfx's main.py)
from cgfx import swizzler                         # noqa: E402
from cgfx.mtob import DepthFlag, MTOBFlag         # noqa: E402
from cgfx.sobj import BillboardMode               # noqa: E402
from cgfx.txob import TextureFormat               # noqa: E402
from cgfx.canm import CANMBoneTransform           # noqa: E402

SCENE = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "scene")
CGFX_LIMIT = 0x80000
KNOWN_GOOD_TEX = 458752      # Astra's 4-mesh MDK banner, ran on the owner's New 3DS 2026-11-27 (Forsaken: 360,448)
LIMITS = dict(meshes=8, bones=8, members=4, tex=KNOWN_GOOD_TEX)
if os.environ.get("NO_BUDGET") == "1":      # bisect variant C only: the budget is the thing under test
    LIMITS = {}
g = json.load(open(f"{SCENE}/scene.gltf"))
MODE = g.get("extras", {}).get("mode", "nodes")
DITHER = int(os.environ.get("DITHER", 1 if MODE == "strip" else 0))

# A Transform member has ten slots: scale xyz, rot xyz, ROT W, pos xyz. pycgfx writes the rotation-W slot as
# zero padding but never sets its "absent" flag (bit 22, SPICA GfxAnimTransformFlags.IsRotationWInexistent),
# so a strict reader (SPICA) follows a curve pointer through the empty slot. Every pycgfx banner has this,
# including Forsaken's and T2K's, which run on hardware -- so it is not what froze v2 -- but the flag word is
# then wrong, and the fix should not depend on the HOME Menu tolerating it. ROTW_ABSENT=1 marks the slot
# absent (default for the strip build; the nodes-mode bisect variants stay byte-for-byte v2's pipeline).
ROTW_ABSENT_BIT = 0x400000
ROTW_ABSENT = int(os.environ.get("ROTW_ABSENT", 1 if MODE == "strip" else 0))
if ROTW_ABSENT:
    _refresh = CANMBoneTransform.refresh_struct
    def _refresh_rotw_absent(self):
        _refresh(self)
        self.flags = int(self.flags) | ROTW_ABSENT_BIT
    CANMBoneTransform.refresh_struct = _refresh_rotw_absent


def dither(img, bits):
    """Floyd-Steinberg error diffusion to the per-channel bit depths the format stores (from Forsaken)."""
    a = np.asarray(img.convert("RGBA"), dtype=np.float32).copy()
    h, w, _ = a.shape
    levels = np.array([(1 << b) - 1 for b in bits], dtype=np.float32)
    for y in range(h):
        row = a[y]
        for x in range(w):
            old = row[x].copy()
            new = np.round(np.clip(old, 0, 255) / 255 * levels) / levels * 255
            row[x] = new
            err = old - new
            if x + 1 < w: row[x + 1] += err * 7 / 16
            if y + 1 < h:
                nxt = a[y + 1]
                if x > 0: nxt[x - 1] += err * 3 / 16
                nxt[x] += err * 5 / 16
                if x + 1 < w: nxt[x + 1] += err * 1 / 16
    return Image.fromarray(np.clip(np.round(a), 0, 255).astype(np.uint8), "RGBA")


def install_texture_hook():
    """Same format rule as pycgfx_patch.diff (name ends in _rgb565 -> RGB565, else RGBA4), plus dithering,
    and no silent resize: a texture must already be power-of-two and <= 256."""
    def get_texture(cgfx, gltf, image_id, normal=False):
        image = gltf.model.images[image_id]
        name = image.name
        if name in cgfx.data.textures:
            return cgfx.data.textures[name]
        im = Image.open(os.path.join(SCENE, image.uri)).convert("RGBA")
        for v in im.size:
            if v < 8 or v > 256 or v & (v - 1):
                sys.exit(f"texture {name} is {im.size}: not power-of-two in 8..256 (freezes the console)")
        fmt = TextureFormat.RGB565 if name.endswith("_rgb565") else TextureFormat.RGBA4
        if DITHER:
            im = dither(im, (5, 6, 5, 8) if fmt == TextureFormat.RGB565 else (4, 4, 4, 4))
        txob = swizzler.to_txob(im.transpose(Image.Transpose.FLIP_TOP_BOTTOM), fmt)
        txob.name = name
        cgfx.data.textures.add(name, txob)
        return txob
    pycgfx.gltf_get_texture = get_texture


def items(coll):
    if hasattr(coll, "data") and hasattr(coll.data, "contents"):
        return list(coll.data.contents)
    return [coll[n] for n in coll]


def patch(cgfx):
    cmdl = cgfx.data.models["COMMON"]
    bones = cmdl.skeleton.bones
    for n in g["nodes"]:
        if (n.get("extras") or {}).get("billboardMode"):
            bones[n["name"]].billboard_mode = BillboardMode(n["extras"]["billboardMode"])
    for m in items(cmdl.meshes):
        m.mesh_node_name = m.name.split("_")[0]          # pycgfx names it "<mesh>_<material>"
    for mat in g["materials"]:
        mtob = cmdl.materials[mat["name"]]
        # unlit: stage 0 replaces rgb and alpha with texture 0; later stages pass the previous result through
        mtob.flags = MTOBFlag(0)
        tc = mtob.fragment_shader.texture_combiners
        tc[0].src_rgb = tc[0].src_alpha = 0x003
        tc[0].combine_rgb = tc[0].combine_alpha = 0
        for c in tc[1:]:
            c.src_rgb = c.src_alpha = 0xFFF
            c.combine_rgb = c.combine_alpha = 0
        layer = mat["extras"]["layer"]
        flags = DepthFlag.TestEnabled | DepthFlag.MaskEnabled if layer == 0 else DepthFlag.TestEnabled
        mtob.transluscency_kind = layer
        dop = mtob.fragment_operations.depth_operation
        dop.flags = flags
        dop.commands[0].param = (dop.commands[0].param & ~1) | 1
    canm = cgfx.data.skeletal_animations["COMMON"]
    # Play once and hold: the HOME Menu restarts the animation when the title is selected and loops it at the
    # CANM frame size; curves clamp after their last key. Forsaken holds its intro this way with a frame size
    # of 36,057 (approved on a New 3DS XL), so HOLD_FRAMES=36057 plays Kurt's entrance once and holds the
    # final pose for ~10 minutes before the entrance would replay. LOOP_ONCE=1 instead writes the CANM as
    # one-time (loop mode 0) -- no hardware evidence either way; an experiment only.
    hold = int(os.environ.get("HOLD_FRAMES", 0))
    canm.frame_size = max(hold, g["extras"]["loop"] * 60)
    canm.looping = not int(os.environ.get("LOOP_ONCE", 0))


def stats(cgfx, data):
    cmdl = cgfx.data.models["COMMON"]
    tex = sum(len(cgfx.data.textures[t].pixel_based_image.data) for t in cgfx.data.textures)
    canm = cgfx.data.skeletal_animations["COMMON"]
    return dict(size=len(data), meshes=len(items(cmdl.meshes)), bones=len(list(cmdl.skeleton.bones)),
                members=len(list(canm.member_animations_data)), textures=len(list(cgfx.data.textures)), tex=tex,
                frame_size=canm.frame_size)


def validate(cgfx, data, st):
    errors = []
    cmdl = cgfx.data.models["COMMON"]
    if list(cgfx.data.models) != ["COMMON"]:
        errors.append(f"models dict is {list(cgfx.data.models)}, want ['COMMON']")
    if list(cgfx.data.skeletal_animations) != ["COMMON"]:
        errors.append("skeletal animation is not named COMMON")
    if list(cgfx.data.material_animations):
        errors.append("material animation present (the HOME menu ignores it)")
    bones = cmdl.skeleton.bones
    order = [b for b in bones][1:]
    if order != [n["name"] for n in g["nodes"]]:
        errors.append(f"bone order {order} != glTF node order (pycgfx re-sort moved a bone)")
    for n in g["nodes"]:
        b = bones[n["name"]]
        if b.parent_id != 0:
            errors.append(f"bone {n['name']} is not a child of the scene root")
        if int(b.billboard_mode) != 5:
            errors.append(f"bone {n['name']} billboard {int(b.billboard_mode)}, want 5 (YAxial)")
        p = b.position
        if (p.x, p.y, p.z) != (0, 0, 0):
            errors.append(f"billboard bone {n['name']} is not at the origin")
    for sh in items(cmdl.shapes):
        for ps in items(sh.primitive_sets):
            if ps.skinning_mode != 0:
                errors.append("a shape uses skinning")
        for va in items(sh.vertex_attributes):
            if va.usage.name in ("BoneIndex", "BoneWeight"):
                errors.append("a shape has bone streams")
    canm = cgfx.data.skeletal_animations["COMMON"]
    for name in canm.member_animations_data:
        mb = canm.member_animations_data[name]
        mb.refresh_struct()
        fl = int(mb.flags)
        slots = [mb.scale_x, mb.scale_y, mb.scale_z, mb.rot_x, mb.rot_y, mb.rot_z, None, mb.pos_x, mb.pos_y, mb.pos_z]
        for i, v in enumerate(slots):   # every slot without a curve must be flagged absent (bit 16+i) or constant (bit 6+i)
            if not isinstance(v, (int, float)) and v is not None:
                continue
            if not fl & (0x10000 << i) and not fl & (0x40 << i):
                errors.append(f"animation member {name}: slot {i} has no curve but is neither absent nor constant (flags {fl:#x})")
        if int(mb.primitive_type) != 5:
            errors.append(f"animation member {name} is not Transform (5)")
    for t in cgfx.data.textures:
        if int(cgfx.data.textures[t].hw_format) not in (3, 4):
            errors.append(f"texture {t} is not RGB565/RGBA4")
    for k, lim in LIMITS.items():
        if st[k] > lim:
            errors.append(f"{k} = {st[k]} exceeds the budget {lim}")
    if len(data) >= CGFX_LIMIT:
        errors.append(f"CGFX is {len(data)} bytes, limit {CGFX_LIMIT}")
    return errors


def main():
    install_texture_hook()
    gl = gltflib.GLTF.load(f"{SCENE}/scene.gltf", load_file_resources=True)
    cgfx = pycgfx.convert_gltf(gl)
    if MODE == "strip":
        patch(cgfx)
    data = pycgfx.write(cgfx)
    st = stats(cgfx, data)
    out = f"{SCENE}/COMMON.cgfx"
    open(out, "wb").write(data)
    print(f"{out}: {st['size']} bytes ({st['size'] / CGFX_LIMIT:.1%} of 512 KiB); meshes {st['meshes']}, "
          f"bones {st['bones']}, animated members {st['members']}, textures {st['textures']} = {st['tex']} bytes, "
          f"frame size {st['frame_size']:g}")
    json.dump(st, open(f"{SCENE}/cgfx_stats.json", "w"))
    if MODE == "strip":
        errors = validate(cgfx, data, st)
        for e in errors:
            print("ERROR:", e)
        if errors:
            sys.exit(1)


if __name__ == "__main__":
    main()
