# Bisect tool: mark the rotation-W slot absent (flag bit 22) in every Transform member of every skeletal
# animation of an existing CGFX, changing nothing else. Walks the structure (DATA -> skeletal-animation DICT ->
# CANM -> member DICT), it does not byte-scan.   python patch_rotw.py in.cgfx out.cgfx
import struct, sys

d = bytearray(open(sys.argv[1], "rb").read())
u32 = lambda o: struct.unpack_from("<I", d, o)[0]
i32 = lambda o: struct.unpack_from("<i", d, o)[0]
rel = lambda o: o + i32(o) if i32(o) else 0
assert d[:4] == b"CGFX" and d[0x14:0x18] == b"DATA"

def dict_entries(o):
    n, p = u32(o), rel(o + 4)
    if not p:
        return []
    assert d[p:p + 4] == b"DICT" and u32(p + 8) == n
    return [rel(p + 0x1c + i * 0x10 + 12) for i in range(n)]

changed = 0
for canm in dict_entries(0x14 + 8 + 9 * 8):          # DATA slot 9: skeletal animations
    assert d[canm:canm + 4] == b"CANM"
    for m in dict_entries(canm + 0x18):
        if u32(m + 0x10) != 5:                        # Transform members only
            continue
        fl = u32(m)
        assert i32(m + 0x14 + 6 * 4) == 0, "rotation-W slot is not empty padding"
        if not fl & (0x400000 | 0x1000):
            struct.pack_into("<I", d, m, fl | 0x400000)
            changed += 1
open(sys.argv[2], "wb").write(d)
print(f"marked rotation-W absent in {changed} Transform members")
