# Builds a PCM16 stereo CWAV by reusing the header/INFO layout of a known-good banner CWAV.
import struct,wave,array,sys
ref=open(sys.argv[1],'rb').read(); w=wave.open(sys.argv[2]); out=sys.argv[3]
assert w.getnchannels()==2 and w.getsampwidth()==2
sr=w.getframerate(); n=w.getnframes(); a=array.array('h',w.readframes(n))
L=a[0::2].tobytes(); R=a[1::2].tobytes()
INFO=0x40; DATA=0xa0; body=DATA+8
c0=0x18; c1=c0+len(L)
# keep each channel 0x20-aligned in absolute file position, like the reference
pad1=(-(body+c1))%0x20; c1+=pad1
datasize=8+c1+len(R); fsize=DATA+datasize
h=bytearray(ref[:DATA])
struct.pack_into('<I',h,0x0c,fsize)
struct.pack_into('<I',h,0x28,datasize)            # DATA block size in block ref table
struct.pack_into('<I',h,INFO+0x0c,sr)
struct.pack_into('<I',h,INFO+0x10,0)              # loop start
struct.pack_into('<I',h,INFO+0x14,n)              # end frame
# channel info sample refs (relative to DATA body)
for i,off in enumerate([c0,c1]):
    r=INFO+0x1c+4+i*8+4; ci=INFO+0x1c+struct.unpack_from('<I',h,r)[0]
    struct.pack_into('<I',h,ci+4,off)
d=bytearray(b'DATA'+struct.pack('<I',datasize)+b'\0'*c0+L+b'\0'*pad1+R)
open(out,'wb').write(bytes(h)+bytes(d)); print('frames',n,'sr',sr,'size',fsize,'dur',n/sr)
