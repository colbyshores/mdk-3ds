# Simulates the HOME Menu banner camera view (mono, 400x240, 30 fps) of a built scene:
#   python sim.py <scene dir> [out.mp4] [wav]
# Textures are decoded from the built COMMON.cgfx (so RGBA4/RGB565 quantisation and dithering show), the
# node animation is evaluated from scene.gltf (STEP or LINEAR, translation and scale), and every quad of every
# mesh is projected through the banner camera; quads that land outside the view are dropped, as the GPU
# would clip them. Straight-alpha SrcAlpha/InvSrcAlpha blend, bg first. It models neither the HOME menu's
# turn of the model nor its oval mask (see README.md).
import struct, json, math, os, sys, subprocess
import numpy as np
from PIL import Image

SCENE = sys.argv[1]
OUT_MP4 = sys.argv[2] if len(sys.argv) > 2 else os.path.join(SCENE, "sim.mp4")
WAV = sys.argv[3] if len(sys.argv) > 3 else None
d = open(f"{SCENE}/COMMON.cgfx", "rb").read()
u32 = lambda o: struct.unpack_from("<I", d, o)[0]
def rel(o): v = struct.unpack_from("<i", d, o)[0]; return o + v if v else 0
def cstr(o): return d[o:d.index(b"\0", o)].decode()

# ---- decode textures (TXOB: ImageTexture at +0x18, PixelBasedImage pointer at +0x38) ----
dic = rel(0x14 + 8 + 8 + 4)
zz = []
for i in range(64):
    x = y = 0
    for b in range(3): x |= ((i >> (2 * b)) & 1) << b; y |= ((i >> (2 * b + 1)) & 1) << b
    zz.append((x, y))
tex = {}
for i in range(u32(dic + 8)):
    no = dic + 0x1c + i * 0x10
    name, o = cstr(rel(no + 8)), rel(no + 12)
    h, w, fmt = u32(o + 0x18), u32(o + 0x1c), u32(o + 0x34)
    img = rel(o + 0x38); size = u32(img + 8); dp = rel(img + 12); raw = d[dp:dp + size]
    a = np.zeros((h, w, 4), np.uint8); p = 0
    for ty in range(h // 8):
        for tx in range(w // 8):
            for k in range(64):
                v = raw[p] | raw[p + 1] << 8; p += 2; x, y = zz[k]
                a[ty * 8 + y, tx * 8 + x] = (((v >> 11) << 3, ((v >> 5) & 63) << 2, (v & 31) << 3, 255) if fmt == 3 else
                                             ((v >> 12) * 17, ((v >> 8) & 15) * 17, ((v >> 4) & 15) * 17, (v & 15) * 17))
    tex[name] = Image.fromarray(a, "RGBA").transpose(Image.Transpose.FLIP_TOP_BOTTOM)

g = json.load(open(f"{SCENE}/scene.gltf")); binary = open(f"{SCENE}/scene.bin", "rb").read()
def accessor(i):
    a = g["accessors"][i]; bv = g["bufferViews"][a["bufferView"]]
    n = {"SCALAR": 1, "VEC2": 2, "VEC3": 3}[a["type"]]; fmt = {5126: "f", 5123: "H"}[a["componentType"]]
    vals = struct.unpack_from(f"<{a['count'] * n}{fmt}", binary, bv["byteOffset"])
    return [vals[k * n:(k + 1) * n] for k in range(a["count"])] if n > 1 else list(vals)
mat_tex = [g["images"][g["textures"][m["pbrMetallicRoughness"]["baseColorTexture"]["index"]]["source"]]["name"]
           for m in g["materials"]]
anims = {}
for ch in g["animations"][0]["channels"]:
    s = g["animations"][0]["samplers"][ch["sampler"]]
    anims[(ch["target"]["node"], ch["target"]["path"])] = (accessor(s["input"]), accessor(s["output"]), s["interpolation"])
def sample(node, path, t, rest):
    if (node, path) not in anims: return rest
    ts, vs, interp = anims[(node, path)]
    if t <= ts[0]: return vs[0]
    if t >= ts[-1]: return vs[-1]
    k = max(i for i in range(len(ts)) if ts[i] <= t)
    if interp == "STEP": return vs[k]
    f = (t - ts[k]) / (ts[k + 1] - ts[k])
    return tuple(a + (b - a) * f for a, b in zip(vs[k], vs[k + 1]))

CAM_Y, D = 1.0, 44.786; SW, SH = 400, 240; F = (SH / 2) / math.tan(0.523599 / 2)
def project(x, y, z): return SW / 2 + x * F / (D - z), SH / 2 - (y - CAM_Y) * F / (D - z)
prims = []   # (node index, positions, uvs, indices, texture name, translucent)
for ni, n in enumerate(g["nodes"]):
    for pr in g["meshes"][n["mesh"]]["primitives"]:
        prims.append((ni, accessor(pr["attributes"]["POSITION"]), accessor(pr["attributes"]["TEXCOORD_0"]),
                      accessor(pr["indices"]), mat_tex[pr["material"]], g["materials"][pr["material"]].get("alphaMode") == "BLEND"))
prims.sort(key=lambda p: p[5])
os.makedirs(f"{SCENE}/sim", exist_ok=True)
frames = int(round(g.get("extras", {}).get("loop", 6.0) * 30))
for fi in range(frames):
    t = fi / 30; im = Image.new("RGBA", (SW, SH), (0, 0, 0, 255))
    for ni, pos, uv, idx, tn, _ in prims:
        n = g["nodes"][ni]
        T = sample(ni, "translation", t, tuple(n.get("translation", (0, 0, 0))))
        S = sample(ni, "scale", t, tuple(n.get("scale", (1, 1, 1))))
        if S[0] < 0.01: continue                        # a hidden frame (nodes mode) is sub-pixel
        for q in range(0, len(idx), 6):                 # every primitive is made of quads (grid or sprite)
            vs = sorted(set(idx[q:q + 6]))
            P = [(pos[v][0] * S[0] + T[0], pos[v][1] * S[1] + T[1], pos[v][2] * S[2] + T[2]) for v in vs]
            xs, ys = zip(*[project(*p) for p in P])
            x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
            if x1 < 0 or x0 > SW or y1 < 0 or y0 > SH: continue
            us = [uv[v][0] for v in vs]; vv = [uv[v][1] for v in vs]
            t_ = tex[tn]; W, H = t_.size
            # glTF uv v=0 is the image top; inset half-texel UVs -> crop texel edges
            box = (max(0, min(us) * W - 0.5), max(0, min(vv) * H - 0.5), min(W, max(us) * W + 0.5), min(H, max(vv) * H + 0.5))
            ix0, iy0, ix1, iy1 = math.floor(x0 + 0.5), math.floor(y0 + 0.5), math.floor(x1 + 0.5), math.floor(y1 + 0.5)
            spr = t_.resize((max(1, ix1 - ix0), max(1, iy1 - iy0)), Image.BILINEAR, box=box)
            im.alpha_composite(spr, (ix0, iy0))
    im.convert("RGB").save(f"{SCENE}/sim/s{fi:03d}.png")
cmd = ["ffmpeg", "-v", "error", "-y", "-framerate", "30", "-i", f"{SCENE}/sim/s%03d.png"]
if WAV: cmd += ["-i", WAV, "-c:a", "aac"]
cmd += ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", OUT_MP4]
subprocess.run(cmd, check=True)
print("wrote", OUT_MP4, frames, "frames")
