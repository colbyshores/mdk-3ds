# Per-tick check of what the HOME camera sees, read back from the built CGFX alone (no glTF):
#   python verify_frames.py <file.cgfx | file.bnr> [--res 8] [--until 400]
# It decodes every shape's float position stream and its bone, every skeletal-animation Transform member's
# curves (StepLinear64 keys, as pycgfx and Astra's kit write them), and evaluates them every 1/RES of a 60 Hz
# tick under THREE interpretations of the curves, because the HOME Menu's own one is not documented:
#   step    hold each key's value until the next key   (what interpolation 0 is meant to mean)
#   linear  linear between keys                        (what interpolation 1 means)
#   nearest value of the nearest key                   (the "Nearest" name the format gives interpolation 0)
# Each Kurt quad (4 consecutive vertices of a non-bg shape) is moved by its bone's translation (+ the bone's
# rest translation) and projected through the banner camera; a quad counts as visible if any part of it lands
# on the 400x240 view. The check: exactly one Kurt quad visible at every sample. Billboards and HOME's turn are
# rotations about bones on the vertical axis at x = z = 0, so they cannot move a quad vertically and are ignored.
import math, struct, sys

args = sys.argv[1:]
path = args[0]
RES = int(args[args.index("--res") + 1]) if "--res" in args else 8
UNTIL = float(args[args.index("--until") + 1]) if "--until" in args else None
d = open(path, "rb").read()
if d[:4] == b"CBMD":
    sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
    import lz11
    d = lz11.decompress(d[struct.unpack_from("<I", d, 8)[0]:])[0]
u32 = lambda o: struct.unpack_from("<I", d, o)[0]
i32 = lambda o: struct.unpack_from("<i", d, o)[0]
f32 = lambda o: struct.unpack_from("<f", d, o)[0]
rel = lambda o: o + i32(o) if i32(o) else 0
def cstr(o): return d[o:d.index(b"\0", o)].decode("latin1") if o else None
def dict_entries(o):
    n, p = u32(o), rel(o + 4)
    if not p: return []
    assert d[p:p + 4] == b"DICT" and u32(p + 8) == n
    return [(cstr(rel(p + 0x1c + i * 16 + 8)), rel(p + 0x1c + i * 16 + 12)) for i in range(n)]

mdl = dict_entries(0x14 + 8)[0][1]
base = mdl + 0xb4
sk = rel(base + 44)
bones = {}                                    # index -> (name, rest translation)
for i, (bn, bo) in enumerate(dict_entries(sk + 0x18)):
    bones[i] = (bn, struct.unpack_from("<3f", d, bo + 0x38))
meshes = [rel(rel(base + 4) + 4 * k) for k in range(u32(base))]
shapes = [rel(rel(base + 20) + 4 * k) for k in range(u32(base + 16))]
mats = dict_entries(base + 8)
groups = []                                   # (mesh name, bone name, [quad vertex lists])
for mo in meshes:
    so = shapes[u32(mo + 0x18)]
    ps = rel(rel(so + 0x30))                  # first primitive set
    bone = u32(rel(ps + 4)) if u32(ps) else 0
    pos = None
    for j in range(u32(so + 0x38)):
        va = rel(rel(so + 0x3c) + 4 * j)
        if u32(va) == 0x40000001 and u32(va + 4) == 0:       # VertexStream, Position
            n, p = u32(va + 0x14), rel(va + 0x18)
            fmt, comps, scale = u32(va + 0x24), u32(va + 0x28), f32(va + 0x2c)
            assert fmt == 0x1406 and comps == 3, "positions are not float3"
            off = struct.unpack_from("<3f", d, so + 0x20)    # shape position offset
            vs = [struct.unpack_from("<3f", d, p + 12 * k) for k in range(n // 12)]
            pos = [(x * scale + off[0], y * scale + off[1], z * scale + off[2]) for x, y, z in vs]
    groups.append((cstr(rel(mo + 0xc)), bones[bone][0], [pos[q:q + 4] for q in range(0, len(pos), 4)], bones[bone][1]))

# curves: member name -> {'py': [(frame, value)], ...}
SL = ["sx", "sy", "sz", "rx", "ry", "rz", "rw", "px", "py", "pz"]
canm = dict_entries(0x14 + 8 + 9 * 8)[0][1]
frame_size = f32(canm + 0x14); loops = u32(canm + 0x10)
tracks = {}
for mn, mo in dict_entries(canm + 0x18):
    fl = u32(mo); t = {}
    for i, s in enumerate(SL):
        if fl & (0x10000 << i): continue
        if fl & (0x40 << i): t[s] = [(0.0, f32(mo + 0x14 + 4 * i))]; continue
        c = rel(mo + 0x14 + 4 * i); keys = []
        for q in range(u32(c + 16)):
            sg = rel(c + 20 + 4 * q); sfl = u32(sg + 8)
            if sfl & 1: keys.append((f32(sg), f32(sg + 12))); continue
            assert (sfl >> 5) & 7 == 6, "only StepLinear64 keys are decoded"
            keys += [struct.unpack_from("<2f", d, sg + 20 + 8 * z) for z in range(u32(sg + 12))]
        t[s] = keys
    tracks[mn] = t

def ev(keys, f, mode):
    if f <= keys[0][0] or len(keys) == 1: return keys[0][1]
    if f >= keys[-1][0]: return keys[-1][1]
    k = max(i for i in range(len(keys)) if keys[i][0] <= f)
    (f0, v0), (f1, v1) = keys[k], keys[k + 1]
    if f == f0 or mode == "step": return v0
    if mode == "nearest": return v0 if f - f0 < f1 - f else v1
    return v0 + (v1 - v0) * (f - f0) / (f1 - f0)

CAM_Y, D = 1.0, 44.786; SW, SH = 400, 240; F = (SH / 2) / math.tan(0.523599 / 2)
def visible(quad, T):
    xs, ys = [], []
    for x, y, z in quad:
        x, y, z = x + T[0], y + T[1], z + T[2]
        xs.append(SW / 2 + x * F / (D - z)); ys.append(SH / 2 - (y - CAM_Y) * F / (D - z))
    return max(xs) > 0 and min(xs) < SW and max(ys) > 0 and min(ys) < SH

kurt = [g for g in groups if g[1] != "bg" and not g[0].startswith("bg")]
end = UNTIL if UNTIL is not None else max(k[0] for t in tracks.values() for ks in t.values() for k in ks) + 4
print(f"{path}: {len(kurt)} Kurt meshes, {sum(len(g[2]) for g in kurt)} quads; CANM loop={loops} frame size {frame_size:g};"
      f" sampling 0..{end:g} ticks every 1/{RES} tick")
ok = True
for mode in ("step", "linear", "nearest"):
    bad = {0: [], 2: []}; poses = []
    for s in range(int(end * RES) + 1):
        f = s / RES; n = 0; which = None
        for mi, (mesh, bone, quads, rest) in enumerate(kurt):
            t = tracks.get(bone, {})
            T = tuple(ev(t[c], f, mode) if c in t else rest[k] for k, c in enumerate(("px", "py", "pz")))
            for qi, q in enumerate(quads):
                if visible(q, T): n += 1; which = (mi, qi)
        if n == 0: bad[0].append(f)
        elif n > 1: bad[2].append(f)
        if which and (not poses or poses[-1][1] != which): poses.append((f, which))
    res = "OK" if not bad[0] and not bad[2] else "FAIL"
    ok &= res == "OK" or mode != "step"
    print(f"  {mode:7s}: {res}  no-Kurt samples {len(bad[0])} ({len(bad[0]) / RES:g} ticks)"
          f"{' e.g. ' + str(bad[0][:6]) if bad[0] else ''}; two-Kurt samples {len(bad[2])}"
          f"{' e.g. ' + str(bad[2][:6]) if bad[2] else ''}; {len(poses)} poses shown")
    if mode == "step":
        print("           pose changes at ticks", [p[0] for p in poses])
# smallest transition window of any track: the time in which a non-integer evaluation could fall between rows
w = min((b[0] - a[0] for t in tracks.values() for ks in t.values() for a, b in zip(ks, ks[1:]) if a[1] != b[1]), default=None)
print(f"  narrowest value change between consecutive keys: {w:g} ticks")
