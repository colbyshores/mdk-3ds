# Builds the MDK banner scene as glTF for pycgfx (v3).
#
# v2 froze the console on HOME (see README.md). v2 gave every kept FLC frame its own quad, node, bone and
# animation member (30 meshes, 31 bones, 29 animated members) and spread the frames over three 256x256 RGBA4
# sheets (448 KiB of texture, 514,808-byte CGFX). Every banner known to work on this owner's consoles has
# 4-6 meshes, <= 6 bones, <= 3 animated members and <= 352 KiB of texture. v3 keeps the same frames and the
# same timing but draws them with the structure the working banners use:
#
#   MODE=strip (default, the fix)
#     - bg:   one quad, its own root-level bone AT THE ORIGIN with YAxial billboard (the Forsaken/T2K rule for
#             a flat layer that must hold still while HOME turns the model), the quad's offset baked into its
#             vertices.
#     - kurt: ONE mesh per texture sheet holding every frame's quad, all riding ONE bone ("kurt", also
#             billboard 5, rest pose at the origin). Frame k's quad is baked at its real screen place plus
#             k * STRIP_DY world units straight up; the bone's translation-Y animation pulls frame k down
#             into view (y = -k * STRIP_DY) while it is the current frame. Every other frame is then at least
#             STRIP_DY above or below the view. HOME's turn is about the vertical axis and cannot move them
#             vertically, so they never come into view. Only rigid node TRS translation (the animation kind
#             Forsaken's Donna slide proved on hardware) and LINEAR keys are used: a frame change is two keys
#             STEP_EPS seconds apart.
#
#   MODE=nodes (v2's structure, kept for the bisect variants): one quad + node + bone per frame, switched with
#     scale keys (INTERP=STEP as v2, or LINEAR with STEP_EPS-wide ramps); ANIM=0 drops the per-frame members
#     and shows only the final pose (one 2-key linear member on bg keeps a CANM in the file).
#
# Sprite source: SOURCE=flc runs v2's original path (needs the FLC work dir: FLC=/home/claude/flc and its
# kurt_clean/ mattes). SOURCE=sheets (default) cuts the already-feathered sprites back out of a previous
# build's sheets (V2BUILD=v2build: kurt*.png + frames.json + scene.gltf as shipped in v2's source zip), so
# the art is v2's own pixels, only re-packed (and resampled when TEX_SCALE != 0.5).
import json, math, struct, os, sys
from PIL import Image
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "scene")
os.makedirs(OUT, exist_ok=True)
env = os.environ.get
SOURCE = env("SOURCE", "sheets")
MODE = env("MODE", "strip")
INTERP = env("INTERP", "LINEAR")          # nodes mode only; strip is always LINEAR
ANIM = int(env("ANIM", 1))               # nodes mode only
FLC = env("FLC", "/home/claude/flc")
V2BUILD = env("V2BUILD", os.path.join(HERE, "v2build"))
seq = json.load(open(env("TIMELINE", os.path.join(HERE, "timeline.json"))))   # approved 30 fps timeline (90 frames, 2.99 s)

FPS = 30
LOOP = 6.0           # seconds; approved 2.99 s action, then hold the final pose before the loop restarts
TEX_SCALE = float(env("TEX_SCALE", 0.5))   # texels per FLC pixel for Kurt (v2: 0.5)
KURT_Z = 2.0         # world units in front of the background (stereo pop)
HIDDEN = 0.0001      # nodes mode: scale of a hidden frame
STRIP_DY = float(env("STRIP_DY", 60.0))     # strip mode: world units between frames (view is ~23 units tall at z=2)
# A pose change is two LINEAR keys STEP_EPS apart (hold, then jump), so the curve is constant everywhere except
# inside that window whatever interpolation the HOME Menu applies. Default 1/4096 of a 60 Hz tick (exact in
# float32 at these frame numbers); round 2 used 0.001 s = 0.06 tick. Never encode a hold as two far-apart keys:
# a HOME that interpolates between them would scroll the strip and show no Kurt (Astra's flicker, README).
STEP_EPS = float(env("STEP_EPS", 1 / (4096 * 60)))
BG_GRID = int(env("BG_GRID", 1))            # bg quad subdivisions per side (bisect: pad the file with vertex data)

# banner camera (pycgfx banner-camera.gltf)
CAM_Y, CAM_D, YFOV, ASPECT = 1.0, 44.786, 0.523599, 1.66666666667
VIEW_H = 2 * CAM_D * math.tan(YFOV / 2)
VIEW_W = VIEW_H * ASPECT
PW, PH = 600, 360

def plate_to_world(px, py, z):
    """FLC pixel -> world point at depth z that projects onto the same screen spot as the plate pixel."""
    x = (px / PW - 0.5) * VIEW_W
    y = CAM_Y + (0.5 - py / PH) * VIEW_H
    k = (CAM_D - z) / CAM_D
    return x * k, CAM_Y + (y - CAM_Y) * k

def world_to_plate(wx, wy, z):
    k = (CAM_D - z) / CAM_D
    x, y = wx / k, CAM_Y + (wy - CAM_Y) / k
    return (x / VIEW_W + 0.5) * PW, (0.5 - (y - CAM_Y) / VIEW_H) * PH

# ---- choose kept frames: thin action to ~20 fps, keep a few frames of the slow drift -------------
SETTLE_END = 39                     # output index where the approved timeline reaches frame 77
keep_idx = []
for i, s in enumerate(seq):
    if i < SETTLE_END:
        if i % 3 != 2: keep_idx.append(i)
    elif s in (77, 79, 82) and (not keep_idx or seq[keep_idx[-1]] != s):
        keep_idx.append(i)
# show-intervals per kept frame (seconds)
shows = []
for n, i in enumerate(keep_idx):
    t0 = i / FPS
    t1 = keep_idx[n + 1] / FPS if n + 1 < len(keep_idx) else LOOP
    shows.append((seq[i], t0, t1))
print("kept frames:", len(shows), [s[0] for s in shows])

M = 2                                              # transparent margin, texels (at TEX_SCALE 0.5)
items = []
if SOURCE == "flc":
    # ---- v2's original path: Kurt sprites with soft alpha edges from the cleaned FLC mattes ----------
    # alpha = area coverage of the full-res matte at sprite scale, slightly blurred (FEATHER texels) and lifted
    # so thin features (helmet brim, arms) stay solid; colours are bled outward so translucent edge texels carry
    # Kurt's edge colour instead of black. Each sprite gets a transparent margin so the feather isn't clipped.
    from scipy import ndimage
    offs = {int(k): v for k, v in json.load(open(f"{FLC}/kurt_clean/offsets.json")).items()}
    FEATHER = float(env("FEATHER", 0.6))   # gaussian sigma in texels
    LIFT = 1.5                              # alpha gain after blur (keeps interior/thin parts opaque)
    for f, t0, t1 in shows:
        im = Image.open(f"{FLC}/kurt_clean/k{f:03d}.png").convert("RGBA")
        W, H = im.size
        w = max(1, round(W * TEX_SCALE)); h = max(1, round(H * TEX_SCALE))
        cov = np.asarray(im.getchannel("A").resize((w, h), Image.BOX)).astype(np.float32) / 255
        rgb = np.asarray(im.resize((w, h), Image.LANCZOS).convert("RGB")).astype(np.float32)
        cov = np.pad(cov, M); rgb = np.pad(rgb, ((M, M), (M, M), (0, 0)))
        a = np.clip(ndimage.gaussian_filter(cov, FEATHER) * LIFT, 0, 1) if FEATHER > 0 else np.clip(cov * LIFT, 0, 1)
        solid = cov >= 0.5
        filled = solid.copy()
        for _ in range(M + 3):
            grow = ndimage.binary_dilation(filled) & ~filled
            if not grow.any(): break
            wsum = ndimage.uniform_filter(filled.astype(np.float32), 3)
            for c in range(3):
                acc_ = ndimage.uniform_filter(np.where(filled, rgb[..., c], 0), 3)
                rgb[..., c] = np.where(grow, acc_ / np.maximum(wsum, 1e-6), rgb[..., c])
            filled |= grow
        spr = Image.fromarray(np.dstack([np.clip(rgb, 0, 255), a * 255]).round().astype(np.uint8), "RGBA")
        x0, y0, x1, y1 = offs[f]
        sx, sy = (x1 - x0) / w, (y1 - y0) / h                     # FLC px per texel
        rect = (x0 - M * sx, y0 - M * sy, x1 + M * sx, y1 + M * sy)  # quad extent in plate pixels
        items.append(dict(f=f, t0=t0, t1=t1, im=spr, rect=rect))
    bg_img = Image.open(f"{FLC}/frames/f001.png").convert("RGB").resize((256, 128), Image.LANCZOS)
else:
    # ---- cut v2's sprites back out of its sheets; the quad extents come from v2's glTF --------------
    g2 = json.load(open(f"{V2BUILD}/scene.gltf")); fr2 = {d["f"]: d for d in json.load(open(f"{V2BUILD}/frames.json"))}
    sheets2 = {}
    nodes2 = {n["name"]: n for n in g2["nodes"]}; meshes2 = {m["name"]: m for m in g2["meshes"]}
    for f, t0, t1 in shows:
        d = fr2[f]
        if d["sheet"] not in sheets2: sheets2[d["sheet"]] = Image.open(f"{V2BUILD}/kurt{d['sheet']}.png").convert("RGBA")
        u0, v0, u1, v1 = d["uv"]
        x, y = round(u0 * 256 - 0.5), round(v0 * 256 - 0.5)
        tw, th = round((u1 - u0) * 256 + 1), round((v1 - v0) * 256 + 1)
        spr = sheets2[d["sheet"]].crop((x, y, x + tw, y + th))
        n = nodes2[f"k{f:03d}"]; cx, cy, _ = n["translation"]
        mx = g2["accessors"][meshes2[n["name"]]["primitives"][0]["attributes"]["POSITION"]]["max"]
        # v2 pulled the quad in by half a texel on each side; undo that to get the sprite's full plate rect
        px0, py0 = world_to_plate(cx - mx[0], cy + mx[1], KURT_Z); px1, py1 = world_to_plate(cx + mx[0], cy - mx[1], KURT_Z)
        fx, fy = tw / (tw - 1), th / (th - 1)
        mxp, myp = (px0 + px1) / 2, (py0 + py1) / 2
        hwp, hhp = (px1 - px0) / 2 * fx, (py1 - py0) / 2 * fy
        rect = (mxp - hwp, myp - hhp, mxp + hwp, myp + hhp)
        if abs(TEX_SCALE - 0.5) > 1e-9:
            s = TEX_SCALE / 0.5
            # premultiply so the resample doesn't pull black in from transparent texels
            a = np.asarray(spr).astype(np.float32) / 255
            pm = Image.fromarray((np.dstack([a[..., :3] * a[..., 3:], a[..., 3:]]) * 255).round().astype(np.uint8), "RGBA")
            nw, nh = max(1, round(tw * s)), max(1, round(th * s))
            pm = np.asarray(pm.resize((nw, nh), Image.LANCZOS)).astype(np.float32) / 255
            al = np.clip(pm[..., 3:], 0, 1); rgb = np.where(al > 1e-3, pm[..., :3] / np.maximum(al, 1e-3), 0)
            # bleed colour under (near-)transparent texels so bilinear filtering gives no dark fringe
            from scipy import ndimage
            filled = al[..., 0] > 0.02
            for _ in range(3):
                grow = ndimage.binary_dilation(filled) & ~filled
                if not grow.any(): break
                wsum = ndimage.uniform_filter(filled.astype(np.float32), 3)
                for c in range(3):
                    acc_ = ndimage.uniform_filter(np.where(filled, rgb[..., c], 0), 3)
                    rgb[..., c] = np.where(grow, acc_ / np.maximum(wsum, 1e-6), rgb[..., c])
                filled |= grow
            spr = Image.fromarray((np.dstack([np.clip(rgb, 0, 1), al]) * 255).round().astype(np.uint8), "RGBA")
        items.append(dict(f=f, t0=t0, t1=t1, im=spr, rect=rect))
    bg_img = Image.open(f"{V2BUILD}/bg.png").convert("RGB")

# ---- pack the sprites into 256x256 RGBA4 sheets ------------------------------------------------------
import rectpack
SHEET, PAD = 256, 1
MAX_SHEETS = int(env("MAX_SHEETS", 3))
pk = rectpack.newPacker(rotation=False, pack_algo=rectpack.MaxRectsBssf, sort_algo=rectpack.SORT_AREA)
for k, it in enumerate(items):
    pk.add_rect(it["im"].width + PAD, it["im"].height + PAD, rid=k)
for _ in range(MAX_SHEETS):
    pk.add_bin(SHEET, SHEET)
pk.pack()
placed = pk.rect_list()
if len(placed) != len(items):
    sys.exit(f"packing failed: {len(placed)}/{len(items)} frames fit in {MAX_SHEETS} sheets at TEX_SCALE {TEX_SCALE}")
sheets = [Image.new("RGBA", (SHEET, SHEET), (0, 0, 0, 0)) for _ in range(1 + max(b for b, *_ in placed))]
for b, x, y, w, h, k in placed:
    it = items[k]; w, h = it["im"].size
    sheets[b].paste(it["im"], (x, y))
    # sample texel centres half a texel in from the sprite edge so bilinear never reads the neighbour
    it.update(sheet=b, uv=((x + 0.5) / SHEET, (y + 0.5) / SHEET, (x + w - 0.5) / SHEET, (y + h - 0.5) / SHEET))
for n, sh in enumerate(sheets):
    sh.save(f"{OUT}/kurt{n}.png")
print("sheets:", len(sheets), "tex_scale:", TEX_SCALE)
bg_img.save(f"{OUT}/bg.png")

# ---- glTF assembly -------------------------------------------------------------------------------
buf = bytearray(); bviews = []; accs = []
def add(data, target=None):
    while len(buf) % 4: buf.append(0)
    bviews.append(dict(buffer=0, byteOffset=len(buf), byteLength=len(data), **({"target": target} if target else {})))
    buf.extend(data); return len(bviews) - 1
def acc(bv, ctype, count, typ, mn=None, mx=None):
    a = dict(bufferView=bv, componentType=ctype, count=count, type=typ)
    if mn is not None: a.update(min=mn, max=mx)
    accs.append(a); return len(accs) - 1

def quads_prim(quads, material):
    """quads: list of (x0, y0, x1, y1, z, (u0, v0, u1, v1)) in the node's space -> one glTF primitive."""
    pos, nrm, tc, idx = [], [], [], []
    for n, (x0, y0, x1, y1, z, (u0, v0, u1, v1)) in enumerate(quads):
        pos += [x0, y0, z, x1, y0, z, x1, y1, z, x0, y1, z]
        nrm += [0, 0, 1] * 4
        tc += [u0, v1, u1, v1, u1, v0, u0, v0]      # glTF UV: v=0 is the top of the image; y0 is the bottom
        b = 4 * n; idx += [b, b + 1, b + 2, b, b + 2, b + 3]
    xs, ys, zs = pos[0::3], pos[1::3], pos[2::3]
    p = acc(add(struct.pack(f"<{len(pos)}f", *pos), 34962), 5126, len(pos) // 3, "VEC3",
            [min(xs), min(ys), min(zs)], [max(xs), max(ys), max(zs)])
    nn = acc(add(struct.pack(f"<{len(nrm)}f", *nrm), 34962), 5126, len(nrm) // 3, "VEC3")
    t = acc(add(struct.pack(f"<{len(tc)}f", *tc), 34962), 5126, len(tc) // 2, "VEC2")
    i = acc(add(struct.pack(f"<{len(idx)}H", *idx), 34963), 5123, len(idx), "SCALAR")
    return dict(attributes=dict(POSITION=p, NORMAL=nn, TEXCOORD_0=t), indices=i, material=material)

def grid_prim(x0, y0, x1, y1, z, n, material):
    """A quad subdivided n x n (n=1: a plain quad); UVs cover the whole texture."""
    pos, nrm, tc, idx = [], [], [], []
    for j in range(n + 1):
        for i in range(n + 1):
            u, v = i / n, j / n
            pos += [x0 + (x1 - x0) * u, y0 + (y1 - y0) * v, z]; nrm += [0, 0, 1]; tc += [u, 1 - v]
    for j in range(n):
        for i in range(n):
            a = j * (n + 1) + i; b = a + 1; c = a + n + 2; d = a + n + 1
            idx += [a, b, c, a, c, d]
    xs, ys = pos[0::3], pos[1::3]
    p = acc(add(struct.pack(f"<{len(pos)}f", *pos), 34962), 5126, len(pos) // 3, "VEC3", [min(xs), min(ys), z], [max(xs), max(ys), z])
    nn = acc(add(struct.pack(f"<{len(nrm)}f", *nrm), 34962), 5126, len(nrm) // 3, "VEC3")
    t = acc(add(struct.pack(f"<{len(tc)}f", *tc), 34962), 5126, len(tc) // 2, "VEC2")
    i = acc(add(struct.pack(f"<{len(idx)}H", *idx), 34963), 5123, len(idx), "SCALAR")
    return dict(attributes=dict(POSITION=p, NORMAL=nn, TEXCOORD_0=t), indices=i, material=material)

images = [dict(name="bg_rgb565", uri="bg.png")] + [dict(name=f"kurt{n}", uri=f"kurt{n}.png") for n in range(len(sheets))]
samplers = [dict(magFilter=9729, minFilter=9729, wrapS=33071, wrapT=33071)]
textures = [dict(source=i, sampler=0) for i in range(len(images))]
materials = [dict(name="bg_mat", pbrMetallicRoughness=dict(baseColorTexture=dict(index=0), roughnessFactor=1, metallicFactor=0),
                  extras=dict(unlit=True, layer=0))]
for n in range(len(sheets)):
    materials.append(dict(name=f"kurt{n}_mat", alphaMode="BLEND",
                          pbrMetallicRoughness=dict(baseColorTexture=dict(index=1 + n), roughnessFactor=1, metallicFactor=0),
                          extras=dict(unlit=True, layer=1)))

def plate_quad(it, z):
    """the sprite's quad in world space at depth z (pulled in half a texel, matching the inset UVs)"""
    x0, y0, x1, y1 = it["rect"]
    tw, th = it["im"].size; hx, hy = 0.5 * (x1 - x0) / tw, 0.5 * (y1 - y0) / th
    wx0, wy0 = plate_to_world(x0 + hx, y0 + hy, z); wx1, wy1 = plate_to_world(x1 - hx, y1 - hy, z)
    return wx0, wy1, wx1, wy0          # left, bottom, right, top

meshes, nodes = [], []
samp, chans = [], []
def channel(node, path, keys, interp, comps):
    """keys: [(t, value)] with value a scalar replicated to `comps` components, or a tuple"""
    ts = [k[0] for k in keys]
    vs = [c for k in keys for c in (k[1] if isinstance(k[1], (tuple, list)) else (k[1],) * comps)]
    assert all(b > a for a, b in zip(ts, ts[1:])), f"key times must increase: {ts}"
    ia = acc(add(struct.pack(f"<{len(ts)}f", *ts)), 5126, len(ts), "SCALAR", [min(ts)], [max(ts)])
    oa = acc(add(struct.pack(f"<{len(vs)}f", *vs)), 5126, len(ts), "VEC3")
    samp.append(dict(input=ia, output=oa, interpolation=interp))
    chans.append(dict(sampler=len(samp) - 1, target=dict(node=node, path=path)))

def step_keys(changes, end):
    """changes: [(t, value)] piecewise-constant from t; -> keys that hold each value and switch within STEP_EPS
    (for LINEAR curves). The first key is at t=0 and the last at `end`."""
    keys = []
    for n, (t, v) in enumerate(changes):
        if n == 0: keys.append((0.0, v)); continue
        keys.append((t - STEP_EPS, changes[n - 1][1])); keys.append((t, v))
    if keys[-1][0] < end: keys.append((end, keys[-1][1]))
    return keys

if MODE == "strip":
    # bg: its own root-level bone at the origin, billboard 5, quad baked at y = CAM_Y
    meshes.append(dict(name="bg", primitives=[grid_prim(-VIEW_W / 2, CAM_Y - VIEW_H / 2, VIEW_W / 2, CAM_Y + VIEW_H / 2, 0.0,
                                                        BG_GRID, 0)]))
    nodes.append(dict(name="bg", mesh=0, extras=dict(billboardMode=5)))
    # kurt: one bone; one mesh (primitive) per sheet; frame k baked k*STRIP_DY up
    order = sorted(range(len(items)), key=lambda k: items[k]["t0"])
    per_sheet = {}
    for k, ii in enumerate(order):
        it = items[ii]; it["strip"] = k
        x0, y0, x1, y1 = plate_quad(it, KURT_Z)
        per_sheet.setdefault(it["sheet"], []).append((x0, y0 + k * STRIP_DY, x1, y1 + k * STRIP_DY, KURT_Z, it["uv"]))
    prims = [quads_prim(per_sheet[s], 1 + s) for s in sorted(per_sheet)]
    meshes.append(dict(name="kurt", primitives=prims))
    nodes.append(dict(name="kurt", mesh=1, extras=dict(billboardMode=5)))
    changes = [(items[ii]["t0"], (0.0, -items[ii]["strip"] * STRIP_DY, 0.0)) for ii in order]
    channel(1, "translation", step_keys(changes, LOOP), "LINEAR", 3)
else:
    p = grid_prim(-VIEW_W / 2, -VIEW_H / 2, VIEW_W / 2, VIEW_H / 2, 0.0, BG_GRID, 0)
    meshes.append(dict(name="bg", primitives=[p]))
    nodes.append(dict(name="bg", mesh=0, translation=[0, CAM_Y, 0]))
    last = max(items, key=lambda it: it["t0"])
    kurt_nodes = []
    for it in items:
        x0, y0, x1, y1 = plate_quad(it, KURT_Z)
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        meshes.append(dict(name=f"k{it['f']:03d}", primitives=[quads_prim([(x0 - cx, y0 - cy, x1 - cx, y1 - cy, 0.0, it["uv"])], 1 + it["sheet"])]))
        shown = (it["t0"] == 0) if ANIM else (it is last)
        nodes.append(dict(name=f"k{it['f']:03d}", mesh=len(meshes) - 1, translation=[cx, cy, KURT_Z],
                          scale=[1, 1, 1] if shown else [HIDDEN] * 3))
        kurt_nodes.append((len(nodes) - 1, it))
    if ANIM:
        # hidden -> shown at t0 -> hidden at t1 (unless it runs to the loop end)
        for ni, it in kurt_nodes:
            ch = []
            if it["t0"] > 0: ch.append((0.0, HIDDEN))
            ch.append((it["t0"], 1.0))
            if it["t1"] < LOOP: ch.append((it["t1"], HIDDEN))
            if INTERP == "STEP":
                keys = list(ch)
                keys.append((LOOP, keys[-1][1]))
                channel(ni, "scale", keys, "STEP", 3)
            else:
                channel(ni, "scale", step_keys(ch, LOOP), "LINEAR", 3)
    else:
        # no per-frame members: one identity 2-key linear member so the file still carries a CANM
        channel(0, "translation", [(0.0, (0.0, CAM_Y, 0.0)), (LOOP, (0.0, CAM_Y, 0.0))], "LINEAR", 3)

gltf = dict(asset=dict(version="2.0"), scene=0, scenes=[dict(nodes=list(range(len(nodes))))],
            nodes=nodes, meshes=meshes, materials=materials, textures=textures, images=images, samplers=samplers,
            animations=[dict(name="kurt", samplers=samp, channels=chans)],
            accessors=accs, bufferViews=bviews, buffers=[dict(byteLength=len(buf), uri="scene.bin")],
            extras=dict(mode=MODE, strip_dy=STRIP_DY, loop=LOOP))
open(f"{OUT}/scene.bin", "wb").write(buf)
json.dump(gltf, open(f"{OUT}/scene.gltf", "w"), indent=1)
json.dump([dict(f=it["f"], t0=it["t0"], t1=it["t1"], sheet=it["sheet"], uv=it["uv"], strip=it.get("strip")) for it in items],
          open(f"{OUT}/frames.json", "w"), indent=0)
print("mode", MODE, "view", round(VIEW_W, 3), "x", round(VIEW_H, 3), "nodes", len(nodes), "meshes", len(meshes),
      "anim channels", len(chans))
